package consola.evento;

public class ConsultarEvento {
    public void mostrarGE(){

    }
}
