package consola.evento;
import java.util.Scanner;
public class EliminarEvento {
    Scanner sc = new Scanner(System.in);
    public void mostrarGE(){
        try {
            System.out.println("ELIMINAR EVENTO");
            System.out.print("ID del evento: ");
            String id = sc.nextLine();

            if (id.equals("")) {
                System.out.println("ID inválido");
                return;
            }

            System.out.println("Evento eliminado");
        } catch (Exception e) {
            System.out.println("Error al eliminar");
        }
    }
}
