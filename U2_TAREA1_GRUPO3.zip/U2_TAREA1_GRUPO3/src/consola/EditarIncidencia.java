package consola;

public class EditarIncidencia {
    public void mostrarGI(){

    }
}
