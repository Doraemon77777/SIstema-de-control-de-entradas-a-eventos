package consola;

public class ActualizarEvento {
    public void mostrarGE(){

    }
}
