package consola;

public class EliminarEvento {
    public void mostrarGE(){

    }
}
