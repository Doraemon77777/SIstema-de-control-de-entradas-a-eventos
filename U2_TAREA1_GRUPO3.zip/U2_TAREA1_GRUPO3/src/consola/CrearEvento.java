package consola;

public class CrearEvento {
    public void mostrarGE(){

    }
}
