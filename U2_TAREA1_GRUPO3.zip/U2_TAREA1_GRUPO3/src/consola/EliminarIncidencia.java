package consola;

public class EliminarIncidencia {
    public void mostrarGI(){

    }
}
