package consola;

public class AnularVenta {
    public void mostrarGV(){

    }
}
