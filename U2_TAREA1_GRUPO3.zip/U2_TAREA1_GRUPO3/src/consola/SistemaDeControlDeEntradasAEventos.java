package consola;

public class SistemaDeControlDeEntradasAEventos {
    public static void main(String[] args) {

        System.out.println("\n === SISTEMA DE CONTROL DE ENTRADAS A EVENTOS ===");
        System.out.println("Iniciando sistema...");
        System.out.println(" ");

        // Instancia del menú principal
        Menu menu = new Menu();
        menu.mostrarMenu();
    }
}
