package consola;

public class IniciarIncidencia {
    public void mostrarGI(){

    }

}
