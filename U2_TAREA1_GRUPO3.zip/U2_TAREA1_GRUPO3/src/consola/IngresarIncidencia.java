package consola;

public class IngresarIncidencia {
    public void mostrarGI(){

    }
}
