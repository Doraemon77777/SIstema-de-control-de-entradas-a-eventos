package consola;

public class RegistrarVenta {
    public void mostrarGV(){

    }
}
