package consola;

public class ConsultarIncidencia {
    public void mostrarGI(){

    }
}
