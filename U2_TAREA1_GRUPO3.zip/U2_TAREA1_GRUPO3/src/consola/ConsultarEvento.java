package consola;

public class ConsultarEvento {
    public void mostrarGE(){

    }
}
