package consola;

public class ConsultarVenta {
    public void mostrarGV(){

    }
}
