package GUI;
import java.util.Scanner;
public class PedidoGUI {

    private final Scanner sc = new Scanner(System.in);

    public void capturarDatosNuevoPedido() {
        System.out.println("\n--- Registrar Pedido ---");
        System.out.print("Código de pedido: ");
        int codigo = leerEntero();
        System.out.print("Cédula del cliente: ");
        String cedula = sc.nextLine();
        System.out.print("Fecha (dd/mm/aaaa): ");
        String fecha = sc.nextLine();
        System.out.print("Estado: ");
        String estado = sc.nextLine();

    }

    public int capturarIdPedido() {
        System.out.print("Ingrese el código del pedido: ");
        return leerEntero();
    }

    private int leerEntero() {
        while (!sc.hasNextInt()) {
            System.out.print("Ingrese un número válido: ");
            sc.next();
        }
        int valor = sc.nextInt();
        sc.nextLine();
        return valor;
    }
}