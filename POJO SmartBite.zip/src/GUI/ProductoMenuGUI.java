package GUI;
import java.util.Scanner;
public class ProductoMenuGUI {

    private final Scanner sc = new Scanner(System.in);

    public void capturarDatosNuevoProducto() {
        System.out.println("\n--- Registrar Producto del Menú ---");
        System.out.print("ID del producto: ");
        int id = leerEntero();
        System.out.print("Nombre: ");
        String nombre = sc.nextLine();
        System.out.print("Categoría: ");
        String categoria = sc.nextLine();
        System.out.print("Precio: ");
        double precio = leerDouble();
    }

    public void capturarActualizacionProducto() {
        System.out.print("ID del producto a actualizar: ");
        int id = leerEntero();
        System.out.print("Nuevo precio: ");
        double precio = leerDouble();
    }

    public void capturarCriterioConsultaMenu() {
        System.out.print("Consultar productos por categoría: ");
        String categoria = sc.nextLine();
    }

    public int capturarIdProducto() {
        System.out.print("ID del producto: ");
        return leerEntero();
    }

    private int leerEntero() {
        while (!sc.hasNextInt()) {
            System.out.print("Ingrese un número válido: ");
            sc.next();
        }
        int valor = sc.nextInt();
        sc.nextLine();
        return valor;
    }

    private double leerDouble() {
        while (!sc.hasNextDouble()) {
            System.out.print("Ingrese un número válido: ");
            sc.next();
        }
        double valor = sc.nextDouble();
        sc.nextLine();
        return valor;
    }
}