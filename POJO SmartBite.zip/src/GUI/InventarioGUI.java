package GUI;
import java.util.Scanner;
public class InventarioGUI {

    private final Scanner sc = new Scanner(System.in);

    public void capturarNuevoRegistroInventario() {
        System.out.println("\n--- Registrar Inventario ---");
        System.out.print("Código de producto: ");
        int codigo = leerEntero();
        System.out.print("Cantidad disponible: ");
        int cantidad = leerEntero();
    }

    public void capturarConsultaInventario() {
        System.out.print("Consultar inventario por código de producto: ");
        int codigo = leerEntero();
    }

    public void capturarActualizacionInventario() {
        System.out.print("Código de producto a actualizar: ");
        int codigo = leerEntero();
        System.out.print("Nueva cantidad: ");
        int cantidad = leerEntero();
    }

    private int leerEntero() {
        while (!sc.hasNextInt()) {
            System.out.print("Ingrese un número válido: ");
            sc.next();
        }
        int valor = sc.nextInt();
        sc.nextLine();
        return valor;
    }
}