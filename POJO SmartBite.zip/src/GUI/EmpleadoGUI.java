package GUI;
import java.util.Scanner;
public class EmpleadoGUI {

    private final Scanner sc = new Scanner(System.in);

    public void capturarDatosNuevoEmpleado() {
        System.out.println("\n--- Registrar Empleado ---");
        System.out.print("ID: ");
        String id = sc.nextLine();
        System.out.print("Nombres: ");
        String nombres = sc.nextLine();
        System.out.print("Rol: ");
        String rol = sc.nextLine();
    }

    public void capturarActualizacionEmpleado() {
        System.out.print("ID del empleado a actualizar: ");
        String id = sc.nextLine();
        System.out.print("Nuevo rol: ");
        String rol = sc.nextLine();
    }

    public void capturarCriterioBusquedaEmpleado() {
        System.out.print("Buscar empleado por nombre: ");
        String nombre = sc.nextLine();
    }

    public String capturarIdEmpleado() {
        System.out.print("ID del empleado: ");
        return sc.nextLine();
    }
}