package GUI;

import GUI.PedidoGUI;

public class PedidoGUITest {

    public static void main(String[] args) {
        PedidoGUI gui = new PedidoGUI();

        gui.capturarDatosNuevoPedido();

        int id = gui.capturarIdPedido();
        System.out.println("Id capturado: " + id);
    }
}