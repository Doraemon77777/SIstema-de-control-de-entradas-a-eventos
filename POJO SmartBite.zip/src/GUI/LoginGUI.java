package GUI;
import java.util.Scanner;
public class LoginGUI {

    private final Scanner sc = new Scanner(System.in);

    public void login() {
        System.out.println("\n=== INICIO DE SESIÓN (H0) ===");
        System.out.print("Usuario: ");
        String usuario = sc.nextLine();

        System.out.print("Contraseña: ");
        String contrasenia = sc.nextLine();

        System.out.println("Validando credenciales de " + usuario + " ...");
        System.out.println("Inicio de sesión exitoso.\n");
    }
}