package GUI;
import java.util.Scanner;
public class ClienteGUI {

    private final Scanner sc = new Scanner(System.in);

    public void capturarDatosNuevoCliente() {
        System.out.println("\n--- Registrar Cliente ---");
        System.out.print("Cédula: ");
        String cedula = sc.nextLine();
        System.out.print("Nombres: ");
        String nombres = sc.nextLine();
        System.out.print("Teléfono: ");
        String telefono = sc.nextLine();
    }

    public void capturarActualizacionCliente() {
        System.out.print("Cédula del cliente a actualizar: ");
        String cedula = sc.nextLine();
        System.out.print("Nuevo teléfono: ");
        String telefono = sc.nextLine();
    }

    public void capturarCriterioBusqueda() {
        System.out.print("Buscar cliente por cédula: ");
        String cedula = sc.nextLine();
    }

    public String capturarCedulaCliente() {
        System.out.print("Ingrese cédula del cliente: ");
        return sc.nextLine();
    }
}