package GUI;
import java.util.Scanner;
public class VentaGUI {

    private final Scanner sc = new Scanner(System.in);

    public void capturarDatosNuevaVenta() {
        System.out.println("\n--- Registrar Venta ---");
        System.out.print("Código de venta: ");
        int codigo = leerEntero();
        System.out.print("Código de pedido asociado: ");
        int codigoPedido = leerEntero();
        System.out.print("Total: ");
        double total = leerDouble();
        System.out.print("Forma de pago: ");
        String formaPago = sc.nextLine();
    }

    public void capturarCriterioConsulta() {
        System.out.print("Consultar venta por código: ");
        int codigo = leerEntero();
    }

    public void capturarActualizacionVenta() {
        System.out.print("Código de venta a actualizar: ");
        int codigo = leerEntero();
        System.out.print("Nuevo total: ");
        double total = leerDouble();
    }

    public int capturarIdVenta() {
        System.out.print("Código de venta: ");
        return leerEntero();
    }

    private int leerEntero() {
        while (!sc.hasNextInt()) {
            System.out.print("Ingrese un número válido: ");
            sc.next();
        }
        int valor = sc.nextInt();
        sc.nextLine();
        return valor;
    }

    private double leerDouble() {
        while (!sc.hasNextDouble()) {
            System.out.print("Ingrese un número válido: ");
            sc.next();
        }
        double valor = sc.nextDouble();
        sc.nextLine();
        return valor;
    }
}