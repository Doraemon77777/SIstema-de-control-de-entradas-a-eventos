package testDominio;

public class Validador {

    // Validar texto normal
    public static boolean validarTexto(String texto) {
        return texto != null && !texto.trim().isEmpty();
    }

    // Nombre sin caracteres especiales
    public static boolean validarNombre(String nombre) {
        return nombre != null && nombre.matches("^[A-Za-zÁÉÍÓÚáéíóúÑñ ]+$");
    }

    // Teléfono: 7 a 10 dígitos
    public static boolean validarTelefono(String telefono) {
        return telefono != null && telefono.matches("\\d{7,10}");
    }

    // Validación de cédula ecuatoriana
    public static boolean validarCedula(String cedula) {

        if (cedula == null || !cedula.matches("\\d{10}")) {
            return false;
        }

        int provincia = Integer.parseInt(cedula.substring(0, 2));
        if (provincia < 0 || provincia > 24) {
            return false;
        }

        int tercerDigito = Character.getNumericValue(cedula.charAt(2));
        if (tercerDigito >= 6) {
            return false;
        }

        int[] coef = {2,1,2,1,2,1,2,1,2};
        int suma = 0;

        for (int i = 0; i < 9; i++) {
            int val = Character.getNumericValue(cedula.charAt(i)) * coef[i];
            if (val >= 10) val -= 9;
            suma += val;
        }

        int digitoVerificador = suma % 10 == 0 ? 0 : 10 - (suma % 10);
        return digitoVerificador == Character.getNumericValue(cedula.charAt(9));
    }
}