package consola;

import java.util.Scanner;

import GUI.ClienteGUI;


public class
SubMenuClientes {

    private final Scanner sc = new Scanner(System.in);
    private final ClienteGUI clienteGUI = new ClienteGUI();

    public void mostrar() {
        int opcion;
        do {
            System.out.println("\n=== SUBMENÚ GESTIONAR CLIENTES (H4) ===");
            System.out.println("1. Registrar cliente (H4.1)");
            System.out.println("2. Consultar cliente (H4.3)");
            System.out.println("3. Actualizar cliente (H4.2)");
            System.out.println("4. Eliminar cliente (H4.4)");
            System.out.println("0. Volver al menú principal");
            System.out.print("Seleccione una opción: ");

            opcion = leerEntero();

            switch (opcion) {
                case 1 : registrarCliente();break;
                case 2 : consultarCliente();break;
                case 3 : actualizarCliente();break;
                case 4 : eliminarCliente();break;
                case 0 : System.out.println("Regresando al menú principal...");break;
                default : System.out.println("Opción no válida.");
            }
        } while (opcion != 0);
    }

    private void registrarCliente() {
        clienteGUI.capturarDatosNuevoCliente();
        System.out.println("[Simulación] Cliente registrado.");
    }

    private void consultarCliente() {
        clienteGUI.capturarCriterioBusqueda();
        System.out.println("[Simulación] Consulta de cliente.");
    }

    private void actualizarCliente() {
        clienteGUI.capturarActualizacionCliente();
        System.out.println("[Simulación] Cliente actualizado.");
    }

    private void eliminarCliente() {
        String cedula = clienteGUI.capturarCedulaCliente();
        System.out.println("[Simulación] Cliente con cédula " + cedula + " eliminado.");
    }

    private int leerEntero() {
        while (!sc.hasNextInt()) {
            System.out.print("Ingrese un número válido: ");
            sc.next();
        }
        int valor = sc.nextInt();
        sc.nextLine();
        return valor;
    }
}