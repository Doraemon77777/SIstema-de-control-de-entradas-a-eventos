package consola;

import GUI.InventarioGUI;

import java.util.Scanner;

public class SubMenuInventario {

    private final Scanner sc = new Scanner(System.in);
    private final InventarioGUI inventarioGUI = new InventarioGUI();

    public void mostrar() {
        int opcion;
        do {
            System.out.println("\n=== SUBMENÚ GESTIONAR INVENTARIO (H2) ===");
            System.out.println("1. Registrar cantidad disponible (H3.1)");
            System.out.println("2. Consultar inventario (H3.2)");
            System.out.println("3. Actualizar inventario (H3.3)");
            System.out.println("0. Volver al menú principal");
            System.out.print("Seleccione una opción: ");

            opcion = leerEntero();

            switch (opcion) {
                case 1 : registrarCantidad();break;
                case 2 : consultarInventario();break;
                case 3 : actualizarInventario();break;
                case 0 : System.out.println("Regresando al menú principal...");break;
                default : System.out.println("Opción no válida.");
            }
        } while (opcion != 0);
    }

    private void registrarCantidad() {
        inventarioGUI.capturarNuevoRegistroInventario();
        System.out.println("[Simulación] Cantidad registrada.");
    }

    private void consultarInventario() {
        inventarioGUI.capturarConsultaInventario();
        System.out.println("[Simulación] Consulta de inventario realizada.");
    }

    private void actualizarInventario() {
        inventarioGUI.capturarActualizacionInventario();
        System.out.println("[Simulación] Inventario actualizado.");
    }

    private int leerEntero() {
        while (!sc.hasNextInt()) {
            System.out.print("Ingrese un número válido: ");
            sc.next();
        }
        int valor = sc.nextInt();
        sc.nextLine();
        return valor;
    }
}