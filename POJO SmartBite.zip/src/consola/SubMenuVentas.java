package consola;

import GUI.VentaGUI;

import java.util.Scanner;

public class SubMenuVentas {

    private final Scanner sc = new Scanner(System.in);
    private final VentaGUI ventaGUI = new VentaGUI();

    public void mostrar() {
        int opcion;
        do {
            System.out.println("\n=== SUBMENÚ GESTIONAR VENTAS (H3) ===");
            System.out.println("1. Registrar venta (H2.1)");
            System.out.println("2. Consultar venta (H2.2)");
            System.out.println("3. Actualizar venta (H2.3)");
            System.out.println("4. Anular venta (H2.4)");
            System.out.println("0. Volver al menú principal");
            System.out.print("Seleccione una opción: ");

            opcion = leerEntero();

            switch (opcion) {
                case 1 : registrarVenta();break;
                case 2 : consultarVenta();break;
                case 3 : actualizarVenta();break;
                case 4 : anularVenta();break;
                case 0 : System.out.println("Regresando al menú principal...");break;
                default : System.out.println("Opción no válida.");
            }
        } while (opcion != 0);
    }

    private void registrarVenta() {
        ventaGUI.capturarDatosNuevaVenta();
        System.out.println("[Simulación] Venta registrada.");
    }

    private void consultarVenta() {
        ventaGUI.capturarCriterioConsulta();
        System.out.println("[Simulación] Consulta de venta.");
    }

    private void actualizarVenta() {
        ventaGUI.capturarActualizacionVenta();
        System.out.println("[Simulación] Venta actualizada.");
    }

    private void anularVenta() {
        int id = ventaGUI.capturarIdVenta();
        System.out.println("[Simulación] Venta " + id + " anulada.");
    }

    private int leerEntero() {
        while (!sc.hasNextInt()) {
            System.out.print("Ingrese un número válido: ");
            sc.next();
        }
        int valor = sc.nextInt();
        sc.nextLine();
        return valor;
    }
}