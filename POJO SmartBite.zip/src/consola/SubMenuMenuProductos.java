package consola;

import GUI.ProductoMenuGUI;

import java.util.Scanner;

public class SubMenuMenuProductos {

    private final Scanner sc = new Scanner(System.in);
    private final ProductoMenuGUI productoGUI = new ProductoMenuGUI();

    public void mostrar() {
        int opcion;
        do {
            System.out.println("\n=== SUBMENÚ GESTIONAR MENÚ (H6) ===");
            System.out.println("1. Registrar producto del menú (H6.1)");
            System.out.println("2. Consultar menú (H6.3)");
            System.out.println("3. Actualizar producto del menú (H6.2)");
            System.out.println("4. Eliminar producto del menú (H6.4)");
            System.out.println("0. Volver al menú principal");
            System.out.print("Seleccione una opción: ");

            opcion = leerEntero();

            switch (opcion) {
                case 1 : registrarProducto();break;
                case 2 : consultarMenu();break;
                case 3 : actualizarProducto();break;
                case 4 : eliminarProducto();break;
                case 0 : System.out.println("Regresando al menú principal...");break;
                default : System.out.println("Opción no válida.");
            }
        } while (opcion != 0);
    }

    private void registrarProducto() {
        productoGUI.capturarDatosNuevoProducto();
        System.out.println("[Simulación] Producto del menú registrado.");
    }

    private void consultarMenu() {
        productoGUI.capturarCriterioConsultaMenu();
        System.out.println("[Simulación] Consulta de menú.");
    }

    private void actualizarProducto() {
        productoGUI.capturarActualizacionProducto();
        System.out.println("[Simulación] Producto del menú actualizado.");
    }

    private void eliminarProducto() {
        int id = productoGUI.capturarIdProducto();
        System.out.println("[Simulación] Producto " + id + " eliminado del menú.");
    }

    private int leerEntero() {
        while (!sc.hasNextInt()) {
            System.out.print("Ingrese un número válido: ");
            sc.next();
        }
        int valor = sc.nextInt();
        sc.nextLine();
        return valor;
    }
}