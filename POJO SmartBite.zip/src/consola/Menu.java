package consola;

import GUI.LoginGUI;

import java.util.Scanner;

public class Menu {

    private final Scanner sc = new Scanner(System.in);

    public void mostrarMenuPrincipal() {
        int opcion;

        do {
            System.out.println("====================================");
            System.out.println("  SISTEMA DE GESTIÓN DE RESTAURANTE ");
            System.out.println("====================================");
            System.out.println("1. Ingresar al sistema (H0)");
            System.out.println("2. Gestionar pedidos (H1)");
            System.out.println("3. Gestionar inventario (H2)");
            System.out.println("4. Gestionar ventas (H3)");
            System.out.println("5. Gestionar clientes (H4)");
            System.out.println("6. Gestionar empleados (H5)");
            System.out.println("7. Gestionar menú (H6)");
            System.out.println("0. Salir");
            System.out.print("Seleccione una opción: ");

            opcion = leerEntero();

            switch (opcion) {
                case 1 : new LoginGUI().login();break;
                case 2 : new SubMenuPedidos().mostrar();break;
                case 3 : new SubMenuInventario().mostrar();break;
                case 4 : new SubMenuVentas().mostrar();break;
                case 5 : new SubMenuClientes().mostrar();break;
                case 6 : new SubMenuEmpleados().mostrar();break;
                case 7 : new SubMenuMenuProductos().mostrar();break;
                case 0 : System.out.println("Saliendo del sistema...");break;
                default : System.out.println("Opción no válida.");
            }

        } while (opcion != 0);
    }

    private int leerEntero() {
        while (!sc.hasNextInt()) {
            System.out.print("Ingrese un número válido: ");
            sc.next();
        }
        int valor = sc.nextInt();
        sc.nextLine();
        return valor;
    }
}