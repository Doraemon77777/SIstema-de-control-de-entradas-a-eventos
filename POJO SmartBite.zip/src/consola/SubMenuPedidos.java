package consola;

import GUI.PedidoGUI;

import java.util.Scanner;

public class SubMenuPedidos {

    private final Scanner sc = new Scanner(System.in);
    private final PedidoGUI pedidoGUI = new PedidoGUI();

    public void mostrar() {
        int opcion;
        do {
            System.out.println("\n=== SUBMENÚ GESTIONAR PEDIDOS (H1) ===");
            System.out.println("1. Registrar pedido (H1.1)");
            System.out.println("2. Consultar pedido (H1.2)");
            System.out.println("3. Actualizar pedido (H1.3)");
            System.out.println("4. Cancelar pedido (H1.4)");
            System.out.println("0. Volver al menú principal");
            System.out.print("Seleccione una opción: ");

            opcion = leerEntero();

            switch (opcion) {
                case 1 : registrarPedido();break;
                case 2 : consultarPedido();break;
                case 3 : actualizarPedido();break;
                case 4 : cancelarPedido();break;
                case 0 : System.out.println("Regresando al menú principal...");break;
                default : System.out.println("Opción no válida.");
            }
        } while (opcion != 0);
    }

    private void registrarPedido() {
        System.out.println("[Simulación] Pedido registrado correctamente.");
    }

    private void consultarPedido() {
        int id = pedidoGUI.capturarIdPedido();
        System.out.println("[Simulación] Consultando pedido con id = " + id);
    }

    private void actualizarPedido() {
        int id = pedidoGUI.capturarIdPedido();
        System.out.println("[Simulación] Pedido " + id + " actualizado.");
    }

    private void cancelarPedido() {
        int id = pedidoGUI.capturarIdPedido();
        System.out.println("[Simulación] Pedido " + id + " cancelado.");
    }

    private int leerEntero() {
        while (!sc.hasNextInt()) {
            System.out.print("Ingrese un número válido: ");
            sc.next();
        }
        int valor = sc.nextInt();
        sc.nextLine();
        return valor;
    }
}