package consola;

import GUI.EmpleadoGUI;

import java.util.Scanner;

public class SubMenuEmpleados {

    private final Scanner sc = new Scanner(System.in);
    private final EmpleadoGUI empleadoGUI = new EmpleadoGUI();

    public void mostrar() {
        int opcion;
        do {
            System.out.println("\n=== SUBMENÚ GESTIONAR EMPLEADOS (H5) ===");
            System.out.println("1. Registrar empleado (H5.1)");
            System.out.println("2. Consultar empleado (H5.2)");
            System.out.println("3. Actualizar empleado (H5.3)");
            System.out.println("4. Eliminar empleado (H5.4)");
            System.out.println("0. Volver al menú principal");
            System.out.print("Seleccione una opción: ");

            opcion = leerEntero();

            switch (opcion) {
                case 1 : registrarEmpleado();break;
                case 2 : consultarEmpleado();break;
                case 3 : actualizarEmpleado();break;
                case 4 : eliminarEmpleado();break;
                case 0 : System.out.println("Regresando al menú principal...");break;
                default : System.out.println("Opción no válida.");
            }
        } while (opcion != 0);
    }

    private void registrarEmpleado() {
        empleadoGUI.capturarDatosNuevoEmpleado();
        System.out.println("[Simulación] Empleado registrado.");
    }

    private void consultarEmpleado() {
        empleadoGUI.capturarCriterioBusquedaEmpleado();
        System.out.println("[Simulación] Consulta de empleado.");
    }

    private void actualizarEmpleado() {
        empleadoGUI.capturarActualizacionEmpleado();
        System.out.println("[Simulación] Empleado actualizado.");
    }

    private void eliminarEmpleado() {
        String id = empleadoGUI.capturarIdEmpleado();
        System.out.println("[Simulación] Empleado " + id + " eliminado.");
    }

    private int leerEntero() {
        while (!sc.hasNextInt()) {
            System.out.print("Ingrese un número válido: ");
            sc.next();
        }
        int valor = sc.nextInt();
        sc.nextLine();
        return valor;
    }
}