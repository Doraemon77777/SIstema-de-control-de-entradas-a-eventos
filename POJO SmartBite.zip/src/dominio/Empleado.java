package dominio;

import testDominio.Validador;

public class Empleado {

    private int idUsuario;
    private String nombre;
    private String rol;
    private Credencial credencial;

    public Empleado() {}

    public Empleado(int idUsuario, String nombre, String rol, Credencial credencial) {
        setIdUsuario(idUsuario);
        setNombre(nombre);
        setRol(rol);
        setCredencial(credencial);
    }

    public int getIdUsuario() { return idUsuario; }
    public void setIdUsuario(int idUsuario) {
        if (idUsuario <= 0) throw new IllegalArgumentException("ID inválido");
        this.idUsuario = idUsuario;
    }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) {
        if (!Validador.validarNombre(nombre))
            throw new IllegalArgumentException("Nombre inválido");
        this.nombre = nombre;
    }

    public String getRol() { return rol; }
    public void setRol(String rol) {
        if (!(rol.equals("Administrador") || rol.equals("Cajero") || rol.equals("PersonalCocina")))
            throw new IllegalArgumentException("Rol inválido");
        this.rol = rol;
    }

    public Credencial getCredencial() { return credencial; }
    public void setCredencial(Credencial credencial) {
        if (credencial == null)
            throw new IllegalArgumentException("Credencial no puede ser nula");
        this.credencial = credencial;
    }

    @Override
    public String toString() {
        return "Empleado{" +
                "idUsuario=" + idUsuario +
                ", nombre='" + nombre + '\'' +
                ", rol='" + rol + '\'' +
                ", credencial=" + credencial +
                '}';
    }
}