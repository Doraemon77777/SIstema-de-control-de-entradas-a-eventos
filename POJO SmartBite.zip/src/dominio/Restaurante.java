package dominio;

public class Restaurante {

    private int idRestaurante;
    private String nombre;
    private String telefono;
    private String direccion;

    private Cliente[] clientes;
    private Pedido[] pedidos;
    private Empleado[] empleados;

    public Restaurante() {}

    public Restaurante(int idRestaurante, String nombre, String telefono, String direccion,
                       Cliente[] clientes, Pedido[] pedidos, Empleado[] empleados) {

        this.idRestaurante = idRestaurante;
        this.nombre = nombre;
        this.telefono = telefono;
        this.direccion = direccion;
        this.clientes = clientes;
        this.pedidos = pedidos;
        this.empleados = empleados;
    }

    @Override
    public String toString() {
        return "Restaurante{" +
                "idRestaurante=" + idRestaurante +
                ", nombre='" + nombre + '\'' +
                ", telefono='" + telefono + '\'' +
                ", direccion='" + direccion + '\'' +
                '}';
    }
}