package dominio;

import testDominio.Validador;

public class Credencial {

    private String nombreUsuario;
    private String contrasenia;

    public Credencial() {}

    public Credencial(String nombreUsuario, String contrasenia) {
        setNombreUsuario(nombreUsuario);
        setContrasenia(contrasenia);
    }

    public String getNombreUsuario() { return nombreUsuario; }
    public void setNombreUsuario(String nombreUsuario) {
        if (!Validador.validarTexto(nombreUsuario))
            throw new IllegalArgumentException("Usuario no válido");
        this.nombreUsuario = nombreUsuario;
    }

    public String getContrasenia() { return contrasenia; }
    public void setContrasenia(String contrasenia) {
        if (contrasenia == null || contrasenia.length() < 4)
            throw new IllegalArgumentException("Contraseña mínima de 4 caracteres");
        this.contrasenia = contrasenia;
    }

    @Override
    public String toString() {
        return "Credencial{" +
                "nombreUsuario='" + nombreUsuario + '\'' +
                ", contrasenia='***'}";
    }
}