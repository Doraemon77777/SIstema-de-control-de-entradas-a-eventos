package dominio;

import testDominio.Validador;

public class Venta {

    private int idVenta;
    private String fecha;
    private double total;
    private Pedido pedido;
    private Empleado cajero;

    public Venta() {}

    public Venta(int idVenta, String fecha, double total,
                 Pedido pedido, Empleado cajero) {

        setIdVenta(idVenta);
        setFecha(fecha);
        setTotal(total);
        setPedido(pedido);
        setCajero(cajero);
    }

    public int getIdVenta() { return idVenta; }
    public void setIdVenta(int idVenta) {
        if (idVenta <= 0) throw new IllegalArgumentException("ID Venta inválido");
        this.idVenta = idVenta;
    }

    public String getFecha() { return fecha; }
    public void setFecha(String fecha) {
        if (!Validador.validarTexto(fecha))
            throw new IllegalArgumentException("Fecha inválida");
        this.fecha = fecha;
    }

    public double getTotal() { return total; }
    public void setTotal(double total) {
        if (total < 0) throw new IllegalArgumentException("Total inválido");
        this.total = total;
    }

    public Pedido getPedido() { return pedido; }
    public void setPedido(Pedido pedido) {
        if (pedido == null) throw new IllegalArgumentException("Pedido requerido");
        this.pedido = pedido;
    }

    public Empleado getCajero() { return cajero; }
    public void setCajero(Empleado cajero) {
        if (cajero == null) throw new IllegalArgumentException("Cajero requerido");
        this.cajero = cajero;
    }

    @Override
    public String toString() {
        return "Venta{" +
                "idVenta=" + idVenta +
                ", fecha='" + fecha + '\'' +
                ", total=" + total +
                ", pedido=" + pedido +
                ", cajero=" + cajero +
                '}';
    }
}