package dominio;

import testDominio.Validador;

public class Menu {

    private int idMenu;
    private String categoria;
    private Producto[] productos;

    public Menu() {}

    public Menu(int idMenu, String categoria, Producto[] productos) {
        setIdMenu(idMenu);
        setCategoria(categoria);
        setProductos(productos);
    }

    public int getIdMenu() { return idMenu; }
    public void setIdMenu(int idMenu) {
        if (idMenu <= 0) throw new IllegalArgumentException("ID Menu inválido");
        this.idMenu = idMenu;
    }

    public String getCategoria() { return categoria; }
    public void setCategoria(String categoria) {
        if (!Validador.validarTexto(categoria))
            throw new IllegalArgumentException("Categoría inválida");
        this.categoria = categoria;
    }

    public Producto[] getProductos() { return productos; }
    public void setProductos(Producto[] productos) {
        if (productos == null || productos.length == 0)
            throw new IllegalArgumentException("Debe existir al menos un producto");
        this.productos = productos;
    }

    @Override
    public String toString() {
        return "Menu{" +
                "idMenu=" + idMenu +
                ", categoria='" + categoria + '\'' +
                '}';
    }
}