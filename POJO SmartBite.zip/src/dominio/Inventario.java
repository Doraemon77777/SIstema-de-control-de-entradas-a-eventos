package dominio;

public class Inventario {

    private int idInventario;
    private int cantidadDisponible;
    private Producto producto;

    public Inventario() {}

    public Inventario(int idInventario, int cantidadDisponible, Producto producto) {
        setIdInventario(idInventario);
        setCantidadDisponible(cantidadDisponible);
        setProducto(producto);
    }

    public int getIdInventario() { return idInventario; }
    public void setIdInventario(int idInventario) {
        if (idInventario <= 0) throw new IllegalArgumentException("ID inventario inválido");
        this.idInventario = idInventario;
    }

    public int getCantidadDisponible() { return cantidadDisponible; }
    public void setCantidadDisponible(int cantidadDisponible) {
        if (cantidadDisponible < 0)
            throw new IllegalArgumentException("Cantidad inválida");
        this.cantidadDisponible = cantidadDisponible;
    }

    public Producto getProducto() { return producto; }
    public void setProducto(Producto producto) {
        if (producto == null)
            throw new IllegalArgumentException("Producto no puede ser nulo");
        this.producto = producto;
    }

    @Override
    public String toString() {
        return "Inventario{" +
                "idInventario=" + idInventario +
                ", cantidadDisponible=" + cantidadDisponible +
                ", producto=" + producto +
                '}';
    }
}