package dominio;

import testDominio.Validador;

public class Pedido {

    private int idPedido;
    private String estado;
    private String fecha;
    private Cliente cliente;
    private DetallePedido[] detalles;

    public Pedido() {}

    public Pedido(int idPedido, String estado, String fecha,
                  Cliente cliente, DetallePedido[] detalles) {

        setIdPedido(idPedido);
        setEstado(estado);
        setFecha(fecha);
        setCliente(cliente);
        setDetalles(detalles);
    }

    public int getIdPedido() { return idPedido; }
    public void setIdPedido(int idPedido) {
        if (idPedido <= 0) throw new IllegalArgumentException("ID Pedido inválido");
        this.idPedido = idPedido;
    }

    public String getEstado() { return estado; }
    public void setEstado(String estado) {
        if (!Validador.validarTexto(estado))
            throw new IllegalArgumentException("Estado inválido");
        this.estado = estado;
    }

    public String getFecha() { return fecha; }
    public void setFecha(String fecha) {
        if (!Validador.validarTexto(fecha))
            throw new IllegalArgumentException("Fecha inválida");
        this.fecha = fecha;
    }

    public Cliente getCliente() { return cliente; }
    public void setCliente(Cliente cliente) {
        if (cliente == null)
            throw new IllegalArgumentException("Cliente requerido");
        this.cliente = cliente;
    }

    public DetallePedido[] getDetalles() { return detalles; }
    public void setDetalles(DetallePedido[] detalles) {
        if (detalles == null || detalles.length == 0)
            throw new IllegalArgumentException("Debe existir al menos un detalle");
        this.detalles = detalles;
    }

    @Override
    public String toString() {
        return "Pedido{" +
                "idPedido=" + idPedido +
                ", estado='" + estado + '\'' +
                ", fecha='" + fecha + '\'' +
                ", cliente=" + cliente +
                '}';
    }
}