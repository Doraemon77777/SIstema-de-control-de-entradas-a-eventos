package dominio;

public class DetallePedido {

    private int idDetalle;
    private int cantidad;
    private double subtotal;
    private Producto producto;

    public DetallePedido() {}

    public DetallePedido(int idDetalle, int cantidad, Producto producto) {
        setIdDetalle(idDetalle);
        setCantidad(cantidad);
        setProducto(producto);
        calcularSubtotal();
    }

    public void calcularSubtotal() {
        this.subtotal = producto.getPrecio() * cantidad;
    }

    public int getIdDetalle() { return idDetalle; }
    public void setIdDetalle(int idDetalle) {
        if (idDetalle <= 0) throw new IllegalArgumentException("ID Detalle inválido");
        this.idDetalle = idDetalle;
    }

    public int getCantidad() { return cantidad; }
    public void setCantidad(int cantidad) {
        if (cantidad <= 0) throw new IllegalArgumentException("Cantidad inválida");
        this.cantidad = cantidad;
    }

    public Producto getProducto() { return producto; }
    public void setProducto(Producto producto) {
        if (producto == null) throw new IllegalArgumentException("Producto inválido");
        this.producto = producto;
    }

    @Override
    public String toString() {
        return "DetallePedido{" +
                "idDetalle=" + idDetalle +
                ", cantidad=" + cantidad +
                ", subtotal=" + subtotal +
                ", producto=" + producto +
                '}';
    }
}