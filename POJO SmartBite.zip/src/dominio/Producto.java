package dominio;

import testDominio.Validador;

public class Producto {

    private int idProducto;
    private String nombre;
    private double precio;
    private String categoria;
    private boolean disponible;

    public Producto() {}

    public Producto(int idProducto, String nombre, double precio, String categoria, boolean disponible) {
        setIdProducto(idProducto);
        setNombre(nombre);
        setPrecio(precio);
        setCategoria(categoria);
        this.disponible = disponible;
    }

    public int getIdProducto() { return idProducto; }
    public void setIdProducto(int idProducto) {
        if (idProducto <= 0) throw new IllegalArgumentException("ID inválido");
        this.idProducto = idProducto;
    }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) {
        if (!Validador.validarTexto(nombre))
            throw new IllegalArgumentException("Nombre inválido");
        this.nombre = nombre;
    }

    public double getPrecio() { return precio; }
    public void setPrecio(double precio) {
        if (precio <= 0) throw new IllegalArgumentException("Precio inválido");
        this.precio = precio;
    }

    public String getCategoria() { return categoria; }
    public void setCategoria(String categoria) {
        if (!Validador.validarTexto(categoria))
            throw new IllegalArgumentException("Categoría inválida");
        this.categoria = categoria;
    }

    @Override
    public String toString() {
        return "Producto{" +
                "idProducto=" + idProducto +
                ", nombre='" + nombre + '\'' +
                ", precio=" + precio +
                ", categoria='" + categoria + '\'' +
                ", disponible=" + disponible +
                '}';
    }
}