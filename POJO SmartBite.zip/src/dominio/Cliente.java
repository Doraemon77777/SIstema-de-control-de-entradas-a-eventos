package dominio;

import testDominio.Validador;

public class Cliente {

    private int idCliente;
    private String nombre;
    private String telefono;
    private String direccion;
    private String cedula;

    public Cliente() {}

    public Cliente(int idCliente, String nombre, String telefono, String direccion, String cedula) {

        setIdCliente(idCliente);
        setNombre(nombre);
        setTelefono(telefono);
        setDireccion(direccion);
        setCedula(cedula);
    }

    public int getIdCliente() { return idCliente; }
    public void setIdCliente(int idCliente) {
        if (idCliente <= 0) throw new IllegalArgumentException("ID Cliente inválido");
        this.idCliente = idCliente;
    }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) {
        if (!Validador.validarNombre(nombre))
            throw new IllegalArgumentException("Nombre inválido: solo letras y espacios");
        this.nombre = nombre;
    }

    public String getTelefono() { return telefono; }
    public void setTelefono(String telefono) {
        if (!Validador.validarTelefono(telefono))
            throw new IllegalArgumentException("Teléfono inválido");
        this.telefono = telefono;
    }

    public String getDireccion() { return direccion; }
    public void setDireccion(String direccion) {
        if (!Validador.validarTexto(direccion))
            throw new IllegalArgumentException("La dirección no puede estar vacía");
        this.direccion = direccion;
    }

    public String getCedula() { return cedula; }
    public void setCedula(String cedula) {
        if (!Validador.validarCedula(cedula))
            throw new IllegalArgumentException("Cédula ecuatoriana inválida");
        this.cedula = cedula;
    }

    @Override
    public String toString() {
        return "Cliente{" +
                "idCliente=" + idCliente +
                ", nombre='" + nombre + '\'' +
                ", telefono='" + telefono + '\'' +
                ", direccion='" + direccion + '\'' +
                ", cedula='" + cedula + '\'' +
                '}';
    }
}