package proyecto;

import consola.Menu;

public class ProyectoRestaurante {

    public static void main(String[] args) {
        Menu menu = new Menu();
        menu.mostrarMenuPrincipal();
    }
}